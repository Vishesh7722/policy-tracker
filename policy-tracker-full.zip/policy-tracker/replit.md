# Policy Follow-Up Tracker

A production-ready insurance policy follow-up tracker converted from an Excel workbook.

## Architecture

**Monorepo** managed with pnpm workspaces.

### Artifacts
- `artifacts/policy-tracker` — React + Vite frontend (preview at `/`)
- `artifacts/api-server` — Node.js + Express REST API (at `/api`)

### Shared Libraries
- `lib/db` — Drizzle ORM + PostgreSQL schema
- `lib/api-spec` — OpenAPI spec + Orval codegen
- `lib/api-client-react` — Generated React Query hooks
- `lib/api-zod` — Generated Zod validation schemas

## Excel → App Mapping

| Excel Sheet | App Feature |
|---|---|
| Follow Up Sheet | `/follow-ups` page + full CRUD |
| Dashboard | `/` command center dashboard |
| Account Manager | `/account-managers` page |
| Policy Sent Log Sheet | `/policy-log` page |

## Business Logic (replicated from Excel formulas)

- **1st Follow-Up Due Date** = WORKDAY(Checklist Date, 5) — 5 business days after checklist
- **2nd Follow-Up Due Date** = WORKDAY(1st Sent Date, 5) — 5 business days after 1st sent
- **Status calculation** (IF chain):
  - `Closed` if Policy Sent to Client = Y
  - `2nd Follow-Up Escalation` if 2nd sent and today > WORKDAY(2nd sent date, 2)
  - `2nd Follow-Up Pending` if 1st sent, 2nd not sent, and today > 2nd due date
  - `1st Follow-Up Pending` if 1st not sent and today > 1st due date
  - `Waiting` otherwise
- **Follow-Up Count** = (1st sent Y) + (2nd sent Y)

## Database Tables

- `follow_ups` — main tracking records
- `account_managers` — AM name + email list
- `policy_sent_logs` — audit log of sent policies

## API Routes

- `GET/POST /api/follow-ups` — list (search, filter, sort, paginate) + create
- `GET/PUT/DELETE /api/follow-ups/:id` — read/update/delete one
- `GET /api/follow-ups/export` — download Excel file
- `GET/POST /api/account-managers` — list + create
- `PUT/DELETE /api/account-managers/:id` — update/delete
- `GET/POST /api/policy-sent-logs` — list + create
- `DELETE /api/policy-sent-logs/:id` — delete
- `GET /api/dashboard` — summary KPIs
- `GET /api/dashboard/status-breakdown` — counts per status
- `GET /api/dashboard/am-workload` — per-AM workload
- `GET /api/dashboard/recent-activity` — last 10 updated records

## Development

```bash
# Start the API server
pnpm --filter @workspace/api-server run dev

# Start the frontend
pnpm --filter @workspace/policy-tracker run dev

# Run DB schema changes
pnpm --filter @workspace/db run push

# Regenerate API types after spec changes
pnpm run --filter @workspace/api-spec codegen
```

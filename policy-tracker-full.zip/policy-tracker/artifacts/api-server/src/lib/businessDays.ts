export function addBusinessDays(date: Date, days: number): Date {
  const result = new Date(date);
  let added = 0;
  while (added < days) {
    result.setDate(result.getDate() + 1);
    const day = result.getDay();
    if (day !== 0 && day !== 6) {
      added++;
    }
  }
  return result;
}

export function computeFollowUpStatus(row: {
  firstFollowUpSent: string | null;
  secondFollowUpSent: string | null;
  secondFollowUpSentDate: string | null;
  policySentToClient: string | null;
}): string {
  if (row.policySentToClient === "Y") return "Closed";

  if (row.secondFollowUpSent === "Y") {
    if (row.secondFollowUpSentDate) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const escalationDate = addBusinessDays(new Date(row.secondFollowUpSentDate), 2);
      escalationDate.setHours(0, 0, 0, 0);
      if (today >= escalationDate) return "2nd Follow-Up Escalation";
    }
    return "2nd Follow-Up Escalation";
  }

  if (row.firstFollowUpSent === "Y") {
    return "2nd Follow-Up Pending";
  }

  return "1st Follow-Up Pending";
}

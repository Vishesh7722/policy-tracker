import { Router } from "express";
import { db } from "@workspace/db";
import { followUpsTable } from "@workspace/db/schema";
import { desc } from "drizzle-orm";
import { addBusinessDays, computeFollowUpStatus } from "../lib/businessDays.js";

const router = Router();

function toDateStr(d: Date): string {
  return d.toISOString().split("T")[0];
}

function enrichRow(row: typeof followUpsTable.$inferSelect) {
  const checklistDate = new Date(row.checklistDate);
  const firstDue = addBusinessDays(checklistDate, 5);
  const secondDue = row.firstFollowUpSentDate
    ? addBusinessDays(new Date(row.firstFollowUpSentDate), 5)
    : addBusinessDays(firstDue, 5);

  const firstFollowUpDueDate = toDateStr(firstDue);
  const secondFollowUpDueDate = toDateStr(secondDue);

  const currentStatus = computeFollowUpStatus({
    firstFollowUpSent: row.firstFollowUpSent,
    firstFollowUpSentDate: row.firstFollowUpSentDate,
    secondFollowUpSent: row.secondFollowUpSent,
    secondFollowUpSentDate: row.secondFollowUpSentDate,
    policySentToClient: row.policySentToClient,
    firstFollowUpDueDate,
    secondFollowUpDueDate,
  });

  return { ...row, firstFollowUpDueDate, secondFollowUpDueDate, currentStatus };
}

router.get("/dashboard", async (req, res) => {
  try {
    const rows = await db.select().from(followUpsTable);
    const enriched = rows.map(enrichRow);

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = toDateStr(today);

    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekAgoStr = toDateStr(weekAgo);

    const totalFollowUps = enriched.length;
    const totalActive = enriched.filter((r) => r.currentStatus !== "Closed").length;
    const waitingCount = enriched.filter((r) => r.currentStatus === "Waiting").length;
    const firstFollowUpPending = enriched.filter((r) => r.currentStatus === "1st Follow-Up Pending").length;
    const secondFollowUpPending = enriched.filter((r) => r.currentStatus === "2nd Follow-Up Pending").length;
    const escalations = enriched.filter((r) => r.currentStatus === "2nd Follow-Up Escalation").length;
    const closedThisWeek = enriched.filter(
      (r) => r.currentStatus === "Closed" && r.policySentDate && r.policySentDate >= weekAgoStr
    ).length;
    const dueTodayCount = enriched.filter(
      (r) =>
        r.currentStatus !== "Closed" &&
        (r.firstFollowUpDueDate === todayStr || r.secondFollowUpDueDate === todayStr)
    ).length;

    res.json({
      totalFollowUps,
      totalActive,
      waitingCount,
      firstFollowUpPending,
      secondFollowUpPending,
      escalations,
      closedThisWeek,
      dueTodayCount,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get dashboard stats" });
  }
});

router.get("/dashboard/status-breakdown", async (req, res) => {
  try {
    const rows = await db.select().from(followUpsTable);
    const enriched = rows.map(enrichRow);

    const counts: Record<string, number> = {
      "Waiting": 0,
      "1st Follow-Up Pending": 0,
      "2nd Follow-Up Pending": 0,
      "2nd Follow-Up Escalation": 0,
      "Closed": 0,
    };

    for (const r of enriched) {
      if (counts[r.currentStatus] !== undefined) {
        counts[r.currentStatus]++;
      }
    }

    res.json(Object.entries(counts).map(([status, count]) => ({ status, count })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get status breakdown" });
  }
});

router.get("/dashboard/am-workload", async (req, res) => {
  try {
    const rows = await db.select().from(followUpsTable);
    const enriched = rows.map(enrichRow);

    const amMap: Record<string, { total: number; waiting: number; pending: number; escalations: number; closed: number }> = {};

    for (const r of enriched) {
      if (!amMap[r.am]) {
        amMap[r.am] = { total: 0, waiting: 0, pending: 0, escalations: 0, closed: 0 };
      }
      amMap[r.am].total++;
      if (r.currentStatus === "Waiting") amMap[r.am].waiting++;
      else if (r.currentStatus === "1st Follow-Up Pending" || r.currentStatus === "2nd Follow-Up Pending") amMap[r.am].pending++;
      else if (r.currentStatus === "2nd Follow-Up Escalation") amMap[r.am].escalations++;
      else if (r.currentStatus === "Closed") amMap[r.am].closed++;
    }

    const result = Object.entries(amMap)
      .map(([am, stats]) => ({ am, ...stats }))
      .sort((a, b) => b.total - a.total);

    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get AM workload" });
  }
});

router.get("/dashboard/recent-activity", async (req, res) => {
  try {
    const rows = await db
      .select()
      .from(followUpsTable)
      .orderBy(desc(followUpsTable.updatedAt))
      .limit(10);

    const enriched = rows.map((row) => {
      const checklistDate = new Date(row.checklistDate);
      const firstDue = addBusinessDays(checklistDate, 5);
      const secondDue = row.firstFollowUpSentDate
        ? addBusinessDays(new Date(row.firstFollowUpSentDate), 5)
        : addBusinessDays(firstDue, 5);
      const firstFollowUpDueDate = toDateStr(firstDue);
      const secondFollowUpDueDate = toDateStr(secondDue);
      const followUpCount =
        (row.firstFollowUpSent === "Y" ? 1 : 0) +
        (row.secondFollowUpSent === "Y" ? 1 : 0);
      const currentStatus = computeFollowUpStatus({
        firstFollowUpSent: row.firstFollowUpSent,
        firstFollowUpSentDate: row.firstFollowUpSentDate,
        secondFollowUpSent: row.secondFollowUpSent,
        secondFollowUpSentDate: row.secondFollowUpSentDate,
        policySentToClient: row.policySentToClient,
        firstFollowUpDueDate,
        secondFollowUpDueDate,
      });
      return { ...row, firstFollowUpDueDate, secondFollowUpDueDate, followUpCount, currentStatus };
    });

    res.json(enriched);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get recent activity" });
  }
});

export default router;

import { Router } from "express";
import { db } from "@workspace/db";
import { policySentLogsTable } from "@workspace/db/schema";
import { eq, or, ilike, and, desc } from "drizzle-orm";

const router = Router();

router.get("/policy-sent-logs", async (req, res) => {
  try {
    const { search, am, page = "1", pageSize = "50" } = req.query as Record<string, string>;
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const pageSizeNum = Math.min(200, Math.max(1, parseInt(pageSize, 10) || 50));

    let query = db.select().from(policySentLogsTable).orderBy(desc(policySentLogsTable.sentDate)).$dynamic();

    const conditions = [];
    if (search) {
      conditions.push(
        or(
          ilike(policySentLogsTable.clientName, `%${search}%`),
          ilike(policySentLogsTable.policyNumber, `%${search}%`),
          ilike(policySentLogsTable.am, `%${search}%`),
          ilike(policySentLogsTable.lob, `%${search}%`),
          ilike(policySentLogsTable.sentBy, `%${search}%`)
        )
      );
    }
    if (am) conditions.push(ilike(policySentLogsTable.am, `%${am}%`));

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const allRows = await query;
    const total = allRows.length;
    const totalPages = Math.ceil(total / pageSizeNum);
    const data = allRows.slice((pageNum - 1) * pageSizeNum, pageNum * pageSizeNum);

    res.json({ data, total, page: pageNum, pageSize: pageSizeNum, totalPages });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch policy sent logs" });
  }
});

router.post("/policy-sent-logs", async (req, res) => {
  try {
    const { clientName, policyNumber, lob, term, am, sentDate, sentBy } = req.body;
    const [inserted] = await db.insert(policySentLogsTable).values({
      clientName, policyNumber, lob, term: term ?? "", am, sentDate, sentBy,
    }).returning();
    res.status(201).json(inserted);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create policy sent log" });
  }
});

router.delete("/policy-sent-logs/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    await db.delete(policySentLogsTable).where(eq(policySentLogsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete policy sent log" });
  }
});

export default router;

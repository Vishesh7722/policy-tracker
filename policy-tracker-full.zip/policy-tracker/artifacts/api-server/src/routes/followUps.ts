import { Router } from "express";
import { db } from "@workspace/db";
import { followUpsTable } from "@workspace/db/schema";
import { eq, and, or, ilike, sql, desc, asc } from "drizzle-orm";
import { addBusinessDays, computeFollowUpStatus } from "../lib/businessDays.js";
import * as XLSX from "xlsx";

const router = Router();

function toDateStr(d: Date): string {
  return d.toISOString().split("T")[0];
}

function enrichFollowUp(row: typeof followUpsTable.$inferSelect) {
  const checklistDate = new Date(row.checklistDate);
  const firstDue = addBusinessDays(checklistDate, 5);
  const secondDue = row.firstFollowUpSentDate
    ? addBusinessDays(new Date(row.firstFollowUpSentDate), 5)
    : addBusinessDays(firstDue, 5);

  const firstFollowUpDueDate = toDateStr(firstDue);
  const secondFollowUpDueDate = toDateStr(secondDue);

  const followUpCount =
    (row.firstFollowUpSent === "Y" ? 1 : 0) +
    (row.secondFollowUpSent === "Y" ? 1 : 0);

  const currentStatus = computeFollowUpStatus({
    firstFollowUpSent: row.firstFollowUpSent,
    secondFollowUpSent: row.secondFollowUpSent,
    secondFollowUpSentDate: row.secondFollowUpSentDate,
    policySentToClient: row.policySentToClient,
  });

  return {
    ...row,
    firstFollowUpDueDate,
    secondFollowUpDueDate,
    followUpCount,
    currentStatus,
  };
}

router.get("/follow-ups/export", async (req, res) => {
  try {
    const { status, am } = req.query as Record<string, string>;
    let query = db.select().from(followUpsTable).$dynamic();

    const conditions = [];
    if (am) conditions.push(eq(followUpsTable.am, am));

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const rows = await query;
    const enriched = rows.map(enrichFollowUp);

    let filtered = enriched;
    if (status) {
      filtered = enriched.filter((r) => r.currentStatus === status);
    }

    const wsData = [
      [
        "User", "Checklist Date", "Client Name", "Policy Number", "LOB", "Term",
        "AM", "1st Follow-Up Due Date", "1st Follow-Up Sent (Y/N)", "1st Follow-Up Sent Date",
        "2nd Follow-Up Due Date", "2nd Follow-Up Sent (Y/N)", "2nd Follow-Up Sent Date",
        "Policy Sent to Client (Y/N)", "Policy Sent Date", "FollowUp Count", "Current Status",
      ],
      ...filtered.map((r) => [
        r.user, r.checklistDate, r.clientName, r.policyNumber, r.lob, r.term,
        r.am, r.firstFollowUpDueDate, r.firstFollowUpSent ?? "", r.firstFollowUpSentDate ?? "",
        r.secondFollowUpDueDate, r.secondFollowUpSent ?? "", r.secondFollowUpSentDate ?? "",
        r.policySentToClient ?? "", r.policySentDate ?? "", r.followUpCount, r.currentStatus,
      ]),
    ];

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    XLSX.utils.book_append_sheet(wb, ws, "Follow Up Sheet");
    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", "attachment; filename=follow-ups.xlsx");
    res.send(buf);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to export" });
  }
});

router.get("/follow-ups", async (req, res) => {
  try {
    const {
      search, status, am, user, lob,
      sortBy = "checklistDate", sortDir = "desc",
      page = "1", pageSize = "50",
    } = req.query as Record<string, string>;

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const pageSizeNum = Math.min(200, Math.max(1, parseInt(pageSize, 10) || 50));

    let query = db.select().from(followUpsTable).$dynamic();

    const conditions = [];
    if (search) {
      conditions.push(
        or(
          ilike(followUpsTable.clientName, `%${search}%`),
          ilike(followUpsTable.policyNumber, `%${search}%`),
          ilike(followUpsTable.am, `%${search}%`),
          ilike(followUpsTable.lob, `%${search}%`),
          ilike(followUpsTable.user, `%${search}%`)
        )
      );
    }
    if (am) conditions.push(ilike(followUpsTable.am, `%${am}%`));
    if (user) conditions.push(ilike(followUpsTable.user, `%${user}%`));
    if (lob) conditions.push(ilike(followUpsTable.lob, `%${lob}%`));

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const sortColumn = {
      checklistDate: followUpsTable.checklistDate,
      clientName: followUpsTable.clientName,
      am: followUpsTable.am,
      currentStatus: followUpsTable.updatedAt,
      firstFollowUpDueDate: followUpsTable.checklistDate,
      secondFollowUpDueDate: followUpsTable.checklistDate,
    }[sortBy] ?? followUpsTable.checklistDate;

    query = query.orderBy(sortDir === "asc" ? asc(sortColumn) : desc(sortColumn));

    const allRows = await query;
    let enriched = allRows.map(enrichFollowUp);

    if (status === "Closed") {
      enriched = enriched.filter((r) => r.currentStatus === "Closed");
    } else if (status) {
      enriched = enriched.filter((r) => r.currentStatus === status);
    } else {
      // By default exclude Closed records — they live in the Policy Sent Log
      enriched = enriched.filter((r) => r.currentStatus !== "Closed");
    }

    const total = enriched.length;
    const totalPages = Math.ceil(total / pageSizeNum);
    const data = enriched.slice((pageNum - 1) * pageSizeNum, pageNum * pageSizeNum);

    res.json({ data, total, page: pageNum, pageSize: pageSizeNum, totalPages });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch follow-ups" });
  }
});

router.post("/follow-ups", async (req, res) => {
  try {
    const body = req.body;
    const [inserted] = await db.insert(followUpsTable).values({
      user: body.user,
      checklistDate: body.checklistDate,
      clientName: body.clientName,
      policyNumber: body.policyNumber,
      lob: body.lob,
      term: body.term ?? "",
      am: body.am,
      firstFollowUpSent: body.firstFollowUpSent ?? null,
      firstFollowUpSentDate: body.firstFollowUpSentDate ?? null,
      secondFollowUpSent: body.secondFollowUpSent ?? null,
      secondFollowUpSentDate: body.secondFollowUpSentDate ?? null,
      policySentToClient: body.policySentToClient ?? null,
      policySentDate: body.policySentDate ?? null,
    }).returning();
    res.status(201).json(enrichFollowUp(inserted));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create follow-up" });
  }
});

router.get("/follow-ups/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const [row] = await db.select().from(followUpsTable).where(eq(followUpsTable.id, id));
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(enrichFollowUp(row));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch follow-up" });
  }
});

router.put("/follow-ups/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const body = req.body;
    const updates: Partial<typeof followUpsTable.$inferInsert> = {
      updatedAt: new Date(),
    };
    if (body.user !== undefined) updates.user = body.user;
    if (body.checklistDate !== undefined) updates.checklistDate = body.checklistDate;
    if (body.clientName !== undefined) updates.clientName = body.clientName;
    if (body.policyNumber !== undefined) updates.policyNumber = body.policyNumber;
    if (body.lob !== undefined) updates.lob = body.lob;
    if (body.term !== undefined) updates.term = body.term;
    if (body.am !== undefined) updates.am = body.am;
    if (body.firstFollowUpSent !== undefined) updates.firstFollowUpSent = body.firstFollowUpSent;
    if (body.firstFollowUpSentDate !== undefined) updates.firstFollowUpSentDate = body.firstFollowUpSentDate;
    if (body.secondFollowUpSent !== undefined) updates.secondFollowUpSent = body.secondFollowUpSent;
    if (body.secondFollowUpSentDate !== undefined) updates.secondFollowUpSentDate = body.secondFollowUpSentDate;
    if (body.policySentToClient !== undefined) {
      updates.policySentToClient = body.policySentToClient;
      // Track who set policy as sent
      if (body.policySentToClient === "Y") {
        const s = req.session as any;
        updates.policySentByUser = s?.displayName || s?.username || null;
      } else if (body.policySentToClient === null || body.policySentToClient === "N") {
        updates.policySentByUser = null;
      }
    }
    if (body.policySentDate !== undefined) updates.policySentDate = body.policySentDate;

    const [updated] = await db
      .update(followUpsTable)
      .set(updates)
      .where(eq(followUpsTable.id, id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(enrichFollowUp(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update follow-up" });
  }
});

router.delete("/follow-ups/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    await db.delete(followUpsTable).where(eq(followUpsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete follow-up" });
  }
});

export default router;

import { Router } from "express";
import { db } from "@workspace/db";
import { appUsersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

const router = Router();

router.post("/auth/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: "Username and password are required." });
    }
    const [user] = await db.select().from(appUsersTable).where(eq(appUsersTable.username, username.trim().toLowerCase()));
    if (!user) {
      return res.status(401).json({ error: "Invalid username or password." });
    }
    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      return res.status(401).json({ error: "Invalid username or password." });
    }
    (req.session as any).userId = user.id;
    (req.session as any).username = user.username;
    (req.session as any).displayName = user.displayName;
    (req.session as any).role = user.role;
    res.json({ id: user.id, username: user.username, displayName: user.displayName, role: user.role });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Login failed." });
  }
});

router.post("/auth/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

router.get("/auth/me", (req, res) => {
  const s = req.session as any;
  if (!s.userId) return res.status(401).json({ error: "Not authenticated." });
  res.json({ id: s.userId, username: s.username, displayName: s.displayName, role: s.role });
});

router.post("/auth/register", async (req, res) => {
  try {
    const { username, password, displayName } = req.body;
    if (!username || !password || !displayName) {
      return res.status(400).json({ error: "Display name, username, and password are required." });
    }
    if (password.length < 4) {
      return res.status(400).json({ error: "Password must be at least 4 characters." });
    }
    const passwordHash = await bcrypt.hash(password, 10);
    const [user] = await db.insert(appUsersTable).values({
      username: username.trim().toLowerCase(),
      passwordHash,
      displayName: displayName.trim(),
      role: "user",
    }).returning();
    res.status(201).json({ id: user.id, username: user.username, displayName: user.displayName, role: user.role });
  } catch (err: any) {
    if (err.code === "23505") return res.status(409).json({ error: "Username already taken." });
    req.log.error(err);
    res.status(500).json({ error: "Registration failed." });
  }
});

router.put("/auth/change-password", async (req, res) => {
  try {
    const s = req.session as any;
    if (!s.userId) return res.status(401).json({ error: "Not authenticated." });
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: "Current and new passwords are required." });
    }
    if (newPassword.length < 4) {
      return res.status(400).json({ error: "New password must be at least 4 characters." });
    }
    const [user] = await db.select().from(appUsersTable).where(eq(appUsersTable.id, s.userId));
    if (!user) return res.status(404).json({ error: "User not found." });
    const valid = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!valid) return res.status(400).json({ error: "Current password is incorrect." });
    const passwordHash = await bcrypt.hash(newPassword, 10);
    await db.update(appUsersTable).set({ passwordHash }).where(eq(appUsersTable.id, s.userId));
    res.json({ ok: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to change password." });
  }
});

router.get("/users", async (req, res) => {
  try {
    const s = req.session as any;
    if (!s.userId || s.role !== "admin") return res.status(403).json({ error: "Admin only." });
    const users = await db.select({
      id: appUsersTable.id,
      username: appUsersTable.username,
      displayName: appUsersTable.displayName,
      role: appUsersTable.role,
      createdAt: appUsersTable.createdAt,
    }).from(appUsersTable);
    res.json(users);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch users." });
  }
});

router.post("/users", async (req, res) => {
  try {
    const s = req.session as any;
    if (!s.userId || s.role !== "admin") return res.status(403).json({ error: "Admin only." });
    const { username, password, displayName, role } = req.body;
    if (!username || !password || !displayName) {
      return res.status(400).json({ error: "username, password, and displayName are required." });
    }
    const passwordHash = await bcrypt.hash(password, 10);
    const [user] = await db.insert(appUsersTable).values({
      username: username.trim().toLowerCase(),
      passwordHash,
      displayName: displayName.trim(),
      role: role || "user",
    }).returning();
    res.status(201).json({ id: user.id, username: user.username, displayName: user.displayName, role: user.role });
  } catch (err: any) {
    if (err.code === "23505") return res.status(409).json({ error: "Username already exists." });
    req.log.error(err);
    res.status(500).json({ error: "Failed to create user." });
  }
});

router.put("/users/:id/reset-password", async (req, res) => {
  try {
    const s = req.session as any;
    if (!s.userId || s.role !== "admin") return res.status(403).json({ error: "Admin only." });
    const { newPassword } = req.body;
    if (!newPassword || newPassword.length < 4) {
      return res.status(400).json({ error: "New password must be at least 4 characters." });
    }
    const id = parseInt(req.params.id, 10);
    const passwordHash = await bcrypt.hash(newPassword, 10);
    await db.update(appUsersTable).set({ passwordHash }).where(eq(appUsersTable.id, id));
    res.json({ ok: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to reset password." });
  }
});

router.delete("/users/:id", async (req, res) => {
  try {
    const s = req.session as any;
    if (!s.userId || s.role !== "admin") return res.status(403).json({ error: "Admin only." });
    const id = parseInt(req.params.id, 10);
    if (id === s.userId) return res.status(400).json({ error: "Cannot delete your own account." });
    await db.delete(appUsersTable).where(eq(appUsersTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete user." });
  }
});

export default router;

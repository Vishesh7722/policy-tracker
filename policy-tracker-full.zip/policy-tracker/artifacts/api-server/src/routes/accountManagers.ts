import { Router } from "express";
import { db } from "@workspace/db";
import { accountManagersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/account-managers", async (req, res) => {
  try {
    const rows = await db.select().from(accountManagersTable).orderBy(accountManagersTable.name);
    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch account managers" });
  }
});

router.post("/account-managers", async (req, res) => {
  try {
    const { name, email } = req.body;
    const [inserted] = await db.insert(accountManagersTable).values({ name, email }).returning();
    res.status(201).json(inserted);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create account manager" });
  }
});

router.put("/account-managers/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { name, email } = req.body;
    const [updated] = await db
      .update(accountManagersTable)
      .set({ name, email })
      .where(eq(accountManagersTable.id, id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update account manager" });
  }
});

router.delete("/account-managers/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    await db.delete(accountManagersTable).where(eq(accountManagersTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete account manager" });
  }
});

export default router;

import { Router } from "express";
import { db } from "@workspace/db";
import { followUpsTable } from "@workspace/db/schema";

const router = Router();

router.post("/follow-ups/bulk-import", async (req, res) => {
  try {
    const { records } = req.body as {
      records: {
        user: string;
        checklistDate: string;
        clientName: string;
        policyNumber: string;
        lob: string;
        term: string;
        am: string;
        firstFollowUpSent?: string | null;
        firstFollowUpSentDate?: string | null;
        secondFollowUpSent?: string | null;
        secondFollowUpSentDate?: string | null;
        policySentToClient?: string | null;
        policySentDate?: string | null;
      }[];
    };

    if (!Array.isArray(records) || records.length === 0) {
      return res.status(400).json({ error: "No records provided" });
    }

    const toInsert = records
      .filter((r) => r.clientName && r.policyNumber && r.checklistDate && r.am)
      .map((r) => ({
        user: r.user || "Imported",
        checklistDate: r.checklistDate,
        clientName: r.clientName,
        policyNumber: String(r.policyNumber),
        lob: r.lob || "",
        term: r.term || "",
        am: r.am,
        firstFollowUpSent: r.firstFollowUpSent || null,
        firstFollowUpSentDate: r.firstFollowUpSentDate || null,
        secondFollowUpSent: r.secondFollowUpSent || null,
        secondFollowUpSentDate: r.secondFollowUpSentDate || null,
        policySentToClient: r.policySentToClient || null,
        policySentDate: r.policySentDate || null,
      }));

    if (toInsert.length === 0) {
      return res.status(400).json({ error: "No valid records to import" });
    }

    const inserted = await db.insert(followUpsTable).values(toInsert).returning({ id: followUpsTable.id });

    res.status(201).json({ imported: inserted.length, total: records.length });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to import records" });
  }
});

export default router;

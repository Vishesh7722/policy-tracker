import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import followUpsRouter from "./followUps.js";
import accountManagersRouter from "./accountManagers.js";
import policySentLogsRouter from "./policySentLogs.js";
import dashboardRouter from "./dashboard.js";
import bulkImportRouter from "./bulkImport.js";
import authRouter from "./auth.js";

const router: IRouter = Router();

router.use(authRouter);
router.use(healthRouter);
router.use(bulkImportRouter);
router.use(followUpsRouter);
router.use(accountManagersRouter);
router.use(policySentLogsRouter);
router.use(dashboardRouter);

export default router;

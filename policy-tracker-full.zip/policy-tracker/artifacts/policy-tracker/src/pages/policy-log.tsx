import { useState } from "react";
import { useListFollowUps } from "@workspace/api-client-react";
import { Search, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";

export default function PolicyLog() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 50;

  const { data: logsData, isLoading } = useListFollowUps({
    search: search || undefined,
    status: "Closed",
    page,
    pageSize,
  });

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-muted/30">
      <div className="p-6 border-b border-border/50 bg-background flex flex-col sm:flex-row sm:items-center justify-between gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Policy Sent Log</h1>
          <p className="text-sm text-muted-foreground mt-1">Follow-ups closed after policy was sent to client.</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground bg-emerald-50 border border-emerald-200 rounded-md px-3 py-2">
          <FileText className="w-4 h-4 text-emerald-600" />
          <span className="text-emerald-700 font-medium">Records auto-moved here when Policy Sent = Y</span>
        </div>
      </div>

      <div className="p-6 pb-0 flex-shrink-0">
        <div className="flex items-center gap-4 bg-background p-3 rounded-lg border border-border/50 shadow-sm">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search clients, policy numbers..."
              className="pl-9 border-none shadow-none focus-visible:ring-0 bg-transparent"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            />
          </div>
        </div>
      </div>

      <div className="flex-1 p-6 overflow-hidden">
        <div className="bg-background rounded-lg border border-border/50 shadow-sm h-full flex flex-col">
          <div className="flex-1 overflow-auto">
            <Table className="text-xs">
              <TableHeader className="bg-muted/50 sticky top-0 z-10 shadow-sm">
                <TableRow>
                  <TableHead className="px-3 w-[110px]">User</TableHead>
                  <TableHead className="px-3 whitespace-nowrap w-[90px]">Date</TableHead>
                  <TableHead className="px-3 min-w-[160px]">Client Name</TableHead>
                  <TableHead className="px-3 w-[130px]">Policy #</TableHead>
                  <TableHead className="px-3 w-[70px]">LOB</TableHead>
                  <TableHead className="px-3 w-[55px]">Term</TableHead>
                  <TableHead className="px-3 min-w-[130px]">AM</TableHead>
                  <TableHead className="px-3 whitespace-nowrap w-[90px]">Pol. Sent Date</TableHead>
                  <TableHead className="px-3 w-[100px]">Sent By</TableHead>
                  <TableHead className="px-3 text-center w-[70px]">1st FU</TableHead>
                  <TableHead className="px-3 text-center w-[70px]">2nd FU</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 11 }).map((__, j) => (
                        <TableCell key={j} className="px-3"><Skeleton className="h-4 w-20" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : logsData?.data?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={11} className="text-center py-16 text-muted-foreground">
                      <FileText className="w-10 h-10 mx-auto mb-3 opacity-20" />
                      <p className="font-medium">No closed records yet</p>
                      <p className="text-sm mt-1">Records appear here when "Policy Sent" is set to Y in the Follow-Up list.</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  logsData?.data?.map((fu: any) => (
                    <TableRow key={fu.id} className="hover:bg-muted/30">
                      <TableCell className="px-3 text-muted-foreground">{fu.user}</TableCell>
                      <TableCell className="px-3 whitespace-nowrap">{fu.checklistDate}</TableCell>
                      <TableCell className="px-3 font-medium">{fu.clientName}</TableCell>
                      <TableCell className="px-3 font-mono">{fu.policyNumber}</TableCell>
                      <TableCell className="px-3">{fu.lob}</TableCell>
                      <TableCell className="px-3">{fu.term}</TableCell>
                      <TableCell className="px-3">{fu.am}</TableCell>
                      <TableCell className="px-3 whitespace-nowrap text-emerald-700 font-medium">{fu.policySentDate || "—"}</TableCell>
                      <TableCell className="px-3 font-medium text-blue-700">{fu.policySentByUser || "—"}</TableCell>
                      <TableCell className="px-3 text-center">
                        <span className={`inline-block font-semibold px-2 py-0.5 rounded ${fu.firstFollowUpSent === "Y" ? "bg-emerald-50 text-emerald-700" : "bg-muted text-muted-foreground"}`}>
                          {fu.firstFollowUpSent || "—"}
                        </span>
                      </TableCell>
                      <TableCell className="px-3 text-center">
                        <span className={`inline-block font-semibold px-2 py-0.5 rounded ${fu.secondFollowUpSent === "Y" ? "bg-emerald-50 text-emerald-700" : "bg-muted text-muted-foreground"}`}>
                          {fu.secondFollowUpSent || "—"}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {logsData && logsData.totalPages > 1 && (
            <div className="p-4 border-t border-border/50 flex items-center justify-between bg-muted/20">
              <span className="text-sm text-muted-foreground">
                Showing page {page} of {logsData.totalPages} ({logsData.total} total)
              </span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
                <Button variant="outline" size="sm" disabled={page === logsData.totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useExportFollowUps, useListAccountManagers } from "@workspace/api-client-react";
import { Download, FileSpreadsheet, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const STATUSES = ["Waiting", "1st Follow-Up Pending", "2nd Follow-Up Pending", "2nd Follow-Up Escalation", "Closed"];

export default function Export() {
  const [status, setStatus] = useState<string>("");
  const [am, setAm] = useState<string>("");
  const { toast } = useToast();
  
  const { data: ams } = useListAccountManagers();
  const { refetch, isFetching } = useExportFollowUps(
    { 
      status: status === "all" ? undefined : status, 
      am: am === "all" ? undefined : am 
    },
    { 
      query: { 
        enabled: false,
        retry: false
      } 
    }
  );

  const handleExport = async () => {
    try {
      const result = await refetch();
      if (result.data) {
        const url = window.URL.createObjectURL(new Blob([result.data]));
        const link = document.createElement("a");
        link.href = url;
        const dateStr = new Date().toISOString().split('T')[0];
        link.setAttribute("download", `FollowUps_Export_${dateStr}.xlsx`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        toast({ title: "Success", description: "Export downloaded successfully." });
      } else {
        toast({ title: "Error", description: "No data returned for export.", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to export data.", variant: "destructive" });
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-muted/30 p-6 md:p-12">
      <div className="max-w-2xl mx-auto w-full">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Data Export</h1>
          <p className="text-muted-foreground mt-2">Generate Excel reports of follow-up records.</p>
        </div>

        <Card className="border-border/50 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-primary" />
              Export Configuration
            </CardTitle>
            <CardDescription>Select filters to narrow down the exported data.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Filter className="w-4 h-4 text-muted-foreground" />
                  Filter by Status
                </label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger className="w-full bg-muted/50 border-border/50 focus:ring-primary/20">
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Filter className="w-4 h-4 text-muted-foreground" />
                  Filter by Account Manager
                </label>
                <Select value={am} onValueChange={setAm}>
                  <SelectTrigger className="w-full bg-muted/50 border-border/50 focus:ring-primary/20">
                    <SelectValue placeholder="All Account Managers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Account Managers</SelectItem>
                    {ams?.map(a => <SelectItem key={a.name} value={a.name}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="rounded-md bg-primary/5 p-4 border border-primary/10">
              <p className="text-sm text-primary/80">
                The exported Excel file will contain all fields for the matched records, including computed due dates and current statuses.
              </p>
            </div>
          </CardContent>
          <CardFooter className="bg-muted/30 border-t border-border/50 px-6 py-4">
            <Button 
              onClick={handleExport} 
              disabled={isFetching} 
              className="w-full gap-2 text-md py-6 shadow-sm hover:shadow-md transition-all active:scale-[0.98]"
            >
              <Download className="w-5 h-5" />
              {isFetching ? "Generating Export..." : "Download Excel Report"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

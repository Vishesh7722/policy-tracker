import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Trash2, Plus, Users, KeyRound } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface AppUser {
  id: number;
  username: string;
  displayName: string;
  role: string;
  createdAt: string;
}

export default function UsersPage() {
  const { user: me } = useAuth();
  const { toast } = useToast();
  const [users, setUsers] = useState<AppUser[]>([]);
  const [loading, setLoading] = useState(true);

  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ username: "", password: "", displayName: "", role: "user" });
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");

  const [resetOpen, setResetOpen] = useState(false);
  const [resetTarget, setResetTarget] = useState<AppUser | null>(null);
  const [resetPw, setResetPw] = useState("");
  const [resetConfirm, setResetConfirm] = useState("");
  const [resetError, setResetError] = useState("");
  const [resetSaving, setResetSaving] = useState(false);

  const fetchUsers = () => {
    setLoading(true);
    fetch(`${BASE}/api/users`, { credentials: "include" })
      .then(r => r.json())
      .then(data => { setUsers(data); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => { fetchUsers(); }, []);

  if (me?.role !== "admin") {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <Users className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p className="font-medium">Admin access required</p>
        </div>
      </div>
    );
  }

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");
    setSaving(true);
    try {
      const r = await fetch(`${BASE}/api/users`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(form),
      });
      const data = await r.json();
      if (!r.ok) { setFormError(data.error || "Failed to create user."); return; }
      toast({ title: "User created", description: `${form.displayName} can now log in.` });
      setCreateOpen(false);
      setForm({ username: "", password: "", displayName: "", role: "user" });
      fetchUsers();
    } catch {
      setFormError("Network error.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number, name: string) => {
    if (!confirm(`Delete user "${name}"? This cannot be undone.`)) return;
    const r = await fetch(`${BASE}/api/users/${id}`, { method: "DELETE", credentials: "include" });
    if (r.ok) {
      toast({ title: "User deleted" });
      fetchUsers();
    } else {
      toast({ title: "Error", description: "Could not delete user.", variant: "destructive" });
    }
  };

  const openReset = (u: AppUser) => {
    setResetTarget(u);
    setResetPw(""); setResetConfirm(""); setResetError("");
    setResetOpen(true);
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError("");
    if (resetPw !== resetConfirm) { setResetError("Passwords do not match."); return; }
    if (resetPw.length < 4) { setResetError("Password must be at least 4 characters."); return; }
    setResetSaving(true);
    try {
      const r = await fetch(`${BASE}/api/users/${resetTarget!.id}/reset-password`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ newPassword: resetPw }),
      });
      const data = await r.json();
      if (!r.ok) { setResetError(data.error || "Failed to reset password."); return; }
      toast({ title: "Password reset", description: `Password for ${resetTarget!.displayName} has been updated.` });
      setResetOpen(false);
    } catch {
      setResetError("Network error.");
    } finally {
      setResetSaving(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-muted/30">
      <div className="p-6 border-b border-border/50 bg-background flex items-center justify-between gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">User Management</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage login accounts for PolicyTracker.</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="w-4 h-4" /> Add User</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[400px]">
            <DialogHeader><DialogTitle>Create New User</DialogTitle></DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4 py-2">
              <div className="space-y-1.5">
                <Label>Display Name</Label>
                <Input placeholder="Full name" value={form.displayName} onChange={e => setForm(f => ({ ...f, displayName: e.target.value }))} required />
              </div>
              <div className="space-y-1.5">
                <Label>Username</Label>
                <Input placeholder="login username" value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value }))} required />
              </div>
              <div className="space-y-1.5">
                <Label>Password</Label>
                <Input type="password" placeholder="Set a password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required />
              </div>
              <div className="space-y-1.5">
                <Label>Role</Label>
                <Select value={form.role} onValueChange={v => setForm(f => ({ ...f, role: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">User</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formError && <p className="text-sm text-destructive bg-destructive/10 rounded px-3 py-2">{formError}</p>}
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={saving}>{saving ? "Creating..." : "Create User"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex-1 p-6 overflow-auto">
        <div className="bg-background rounded-lg border border-border/50 shadow-sm">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="px-4">Display Name</TableHead>
                <TableHead className="px-4">Username</TableHead>
                <TableHead className="px-4">Role</TableHead>
                <TableHead className="px-4">Created</TableHead>
                <TableHead className="px-4 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow>
              ) : users.length === 0 ? (
                <TableRow><TableCell colSpan={5} className="text-center py-12 text-muted-foreground">No users yet. Create the first one.</TableCell></TableRow>
              ) : (
                users.map(u => (
                  <TableRow key={u.id} className="group">
                    <TableCell className="px-4 font-medium">{u.displayName}</TableCell>
                    <TableCell className="px-4 text-muted-foreground font-mono text-sm">{u.username}</TableCell>
                    <TableCell className="px-4">
                      <Badge variant={u.role === "admin" ? "default" : "secondary"} className="capitalize">{u.role}</Badge>
                    </TableCell>
                    <TableCell className="px-4 text-muted-foreground text-sm">{new Date(u.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="px-4 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-blue-600"
                          title="Reset password" onClick={() => openReset(u)}>
                          <KeyRound className="w-4 h-4" />
                        </Button>
                        {u.id !== me?.id && (
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            title="Delete user" onClick={() => handleDelete(u.id, u.displayName)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                        {u.id === me?.id && <span className="text-xs text-muted-foreground px-2">(you)</span>}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Reset Password Dialog */}
      <Dialog open={resetOpen} onOpenChange={setResetOpen}>
        <DialogContent className="sm:max-w-[380px]">
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground -mt-2">
            Set a new password for <span className="font-medium text-foreground">{resetTarget?.displayName}</span> ({resetTarget?.username}).
          </p>
          <form onSubmit={handleReset} className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>New Password</Label>
              <Input type="password" placeholder="At least 4 characters" value={resetPw}
                onChange={e => setResetPw(e.target.value)} required disabled={resetSaving} />
            </div>
            <div className="space-y-1.5">
              <Label>Confirm New Password</Label>
              <Input type="password" placeholder="Repeat new password" value={resetConfirm}
                onChange={e => setResetConfirm(e.target.value)} required disabled={resetSaving} />
            </div>
            {resetError && (
              <p className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">{resetError}</p>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setResetOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={resetSaving}>{resetSaving ? "Resetting..." : "Reset Password"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

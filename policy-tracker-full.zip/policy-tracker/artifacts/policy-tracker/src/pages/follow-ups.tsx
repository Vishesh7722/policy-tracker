import { useState, useRef } from "react";
import { useListFollowUps, useCreateFollowUp, useUpdateFollowUp, useDeleteFollowUp, getListFollowUpsQueryKey, useListAccountManagers } from "@workspace/api-client-react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { Upload, Search, Filter, Trash2, Edit2, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import * as XLSX from "xlsx";

const STATUSES = ["1st Follow-Up Pending", "2nd Follow-Up Pending", "2nd Follow-Up Escalation"];

export default function FollowUps() {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string>("");
  const [am, setAm] = useState<string>("");
  const [page, setPage] = useState(1);
  const pageSize = 50;

  const { data: followUpsData, isLoading } = useListFollowUps({
    search: search || undefined,
    status: status === "all" ? undefined : status,
    am: am === "all" ? undefined : am,
    page,
    pageSize,
  });

  const { data: ams } = useListAccountManagers();

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-muted/30">
      <div className="p-6 border-b border-border/50 bg-background flex flex-col sm:flex-row sm:items-center justify-between gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Follow-Up</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage and track client communications.</p>
        </div>
        <ExcelUploadButton />
      </div>

      <div className="p-6 pb-0 flex-shrink-0">
        <div className="flex flex-col sm:flex-row items-center gap-4 bg-background p-3 rounded-lg border border-border/50 shadow-sm">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search clients, policy numbers..."
              className="pl-9 border-none shadow-none focus-visible:ring-0 bg-transparent"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            />
          </div>
          <div className="w-px h-6 bg-border/50 hidden sm:block" />
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Filter className="w-4 h-4 text-muted-foreground ml-2" />
            <Select value={status} onValueChange={(val) => { setStatus(val); setPage(1); }}>
              <SelectTrigger className="w-[180px] border-none shadow-none focus:ring-0 bg-transparent font-medium">
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={am} onValueChange={(val) => { setAm(val); setPage(1); }}>
              <SelectTrigger className="w-[180px] border-none shadow-none focus:ring-0 bg-transparent font-medium">
                <SelectValue placeholder="All Account Managers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Account Managers</SelectItem>
                {ams?.map(a => <SelectItem key={a.name} value={a.name}>{a.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="flex-1 p-6 overflow-hidden">
        <div className="bg-background rounded-lg border border-border/50 shadow-sm h-full flex flex-col">
          <div className="flex-1 overflow-auto">
            <Table className="text-xs">
              <TableHeader className="bg-muted/50 sticky top-0 z-10 shadow-sm">
                <TableRow>
                  <TableHead className="whitespace-nowrap px-2 min-w-[110px]">User</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[90px]">Date</TableHead>
                  <TableHead className="whitespace-nowrap px-2 min-w-[160px]">Client Name</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[120px]">Policy #</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[60px]">LOB</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[55px]">Term</TableHead>
                  <TableHead className="whitespace-nowrap px-2 min-w-[120px] max-w-[160px]">AM</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[85px]">1st Due</TableHead>
                  <TableHead className="whitespace-nowrap px-2 text-center w-[100px]">1st Sent</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[85px]">1st Date</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[85px]">2nd Due</TableHead>
                  <TableHead className="whitespace-nowrap px-2 text-center w-[100px]">2nd Sent</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[85px]">2nd Date</TableHead>
                  <TableHead className="whitespace-nowrap px-2 text-center w-[80px]">Pol. Sent</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[85px]">Pol. Date</TableHead>
                  <TableHead className="whitespace-nowrap px-2 w-[130px]">Status</TableHead>
                  <TableHead className="whitespace-nowrap px-2 text-right w-[70px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 17 }).map((__, j) => (
                        <TableCell key={j} className="px-2"><Skeleton className="h-4 w-12" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : followUpsData?.data?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={17} className="text-center py-12 text-muted-foreground">
                      No follow-ups found matching your criteria.
                    </TableCell>
                  </TableRow>
                ) : (
                  followUpsData?.data?.map((fu: any) => (
                    <TableRow key={fu.id} className="group hover:bg-muted/30">
                      <TableCell className="px-2 text-muted-foreground">{fu.user}</TableCell>
                      <TableCell className="px-2 whitespace-nowrap">{fu.checklistDate}</TableCell>
                      <TableCell className="px-2 font-medium text-foreground max-w-[200px] truncate" title={fu.clientName}>{fu.clientName}</TableCell>
                      <TableCell className="px-2 font-mono whitespace-nowrap">{fu.policyNumber}</TableCell>
                      <TableCell className="px-2 max-w-[60px] truncate" title={fu.lob}>{fu.lob}</TableCell>
                      <TableCell className="px-2 whitespace-nowrap">{fu.term}</TableCell>
                      <TableCell className="px-2 max-w-[160px] truncate" title={fu.am}>{fu.am}</TableCell>
                      <TableCell className="px-3 whitespace-nowrap text-xs text-muted-foreground">{fu.firstFollowUpDueDate || "—"}</TableCell>
                      <TableCell className="px-3">
                        <div className="flex items-center gap-1 justify-center">
                          <YNCell id={fu.id} field="firstFollowUpSent" value={fu.firstFollowUpSent} />
                          <EmailButton followUp={fu} type="1st" />
                        </div>
                      </TableCell>
                      <TableCell className="px-3 whitespace-nowrap text-xs text-muted-foreground">{fu.firstFollowUpSentDate || "—"}</TableCell>
                      <TableCell className="px-3 whitespace-nowrap text-xs text-muted-foreground">{fu.secondFollowUpDueDate || "—"}</TableCell>
                      <TableCell className="px-3">
                        <div className="flex items-center gap-1 justify-center">
                          <YNCell id={fu.id} field="secondFollowUpSent" value={fu.secondFollowUpSent} />
                          <EmailButton followUp={fu} type="2nd" />
                        </div>
                      </TableCell>
                      <TableCell className="px-3 whitespace-nowrap text-xs text-muted-foreground">{fu.secondFollowUpSentDate || "—"}</TableCell>
                      <TableCell className="px-3 text-center">
                        <YNCell id={fu.id} field="policySentToClient" value={fu.policySentToClient} />
                      </TableCell>
                      <TableCell className="px-3 whitespace-nowrap text-xs text-muted-foreground">{fu.policySentDate || "—"}</TableCell>
                      <TableCell className="px-3">
                        <StatusBadge status={fu.currentStatus} />
                      </TableCell>
                      <TableCell className="px-3 text-right">
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <EditFollowUpDialog followUp={fu} ams={ams || []} />
                          <DeleteFollowUpButton id={fu.id} />
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {followUpsData && followUpsData.totalPages > 1 && (
            <div className="p-4 border-t border-border/50 flex items-center justify-between bg-muted/20">
              <span className="text-sm text-muted-foreground">
                Showing page {page} of {followUpsData.totalPages} ({followUpsData.total} total)
              </span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
                <Button variant="outline" size="sm" disabled={page === followUpsData.totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    "Waiting": "bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800",
    "1st Follow-Up Pending": "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-900/30 dark:text-amber-400 dark:border-amber-800/50",
    "2nd Follow-Up Pending": "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/30 dark:text-orange-400 dark:border-orange-800/50",
    "2nd Follow-Up Escalation": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800/50",
    "Closed": "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800/50",
  };
  
  return (
    <Badge variant="outline" className={`font-medium shadow-none px-2.5 py-0.5 ${styles[status] || styles["Waiting"]}`}>
      {status}
    </Badge>
  );
}

function YNCell({ id, field, value }: { id: number; field: string; value: string | null }) {
  const { mutate, isPending } = useUpdateFollowUp();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleChange = (val: string) => {
    const newValue = val === "none" ? null : val;
    mutate(
      { id, data: { [field]: newValue } as any },
      {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getListFollowUpsQueryKey() }),
        onError: () => toast({ title: "Error", description: "Failed to update.", variant: "destructive" }),
      }
    );
  };

  const current = value || "none";

  return (
    <Select value={current} onValueChange={handleChange} disabled={isPending}>
      <SelectTrigger
        className={`h-7 w-16 text-xs font-semibold border shadow-none focus:ring-0 mx-auto
          ${current === "Y" ? "bg-emerald-50 border-emerald-200 text-emerald-700" : ""}
          ${current === "N" ? "bg-red-50 border-red-200 text-red-700" : ""}
          ${current === "none" ? "bg-muted/50 border-border text-muted-foreground" : ""}
        `}
      >
        <SelectValue>{current === "none" ? "—" : current}</SelectValue>
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="none">—</SelectItem>
        <SelectItem value="Y">Y</SelectItem>
        <SelectItem value="N">N</SelectItem>
      </SelectContent>
    </Select>
  );
}

function EmailButton({ followUp, type }: { followUp: any; type: "1st" | "2nd" }) {
  const handleClick = () => {
    const subject = encodeURIComponent(
      `${type} Follow-Up: Policy ${followUp.policyNumber} – ${followUp.clientName}`
    );

    const body1st = `Dear ${followUp.am},

I hope this message finds you well.

This is a friendly 1st follow-up regarding the policy below. We have not yet received confirmation that the policy has been delivered to the client.

Client Name: ${followUp.clientName}
Policy Number: ${followUp.policyNumber}
Line of Business: ${followUp.lob}
Term: ${followUp.term}
Checklist Date: ${followUp.checklistDate}

Please let us know if there are any issues or if additional information is needed.

Thank you for your attention to this matter.

Best regards`;

    const body2nd = `Dear ${followUp.am},

I hope you are doing well.

This is a 2nd follow-up regarding the outstanding policy below. We still have not received confirmation of delivery to the client and wanted to follow up once more before escalating.

Client Name: ${followUp.clientName}
Policy Number: ${followUp.policyNumber}
Line of Business: ${followUp.lob}
Term: ${followUp.term}
Checklist Date: ${followUp.checklistDate}

Please respond at your earliest convenience. If this requires escalation, kindly advise.

Thank you,`;

    const body = encodeURIComponent(type === "1st" ? body1st : body2nd);
    window.open(`mailto:?subject=${subject}&body=${body}`, "_self");
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      className="h-7 w-7 text-muted-foreground hover:text-blue-600 hover:bg-blue-50 flex-shrink-0"
      title={`Open ${type} Follow-Up email in Outlook`}
      onClick={handleClick}
    >
      <Mail className="w-3.5 h-3.5" />
    </Button>
  );
}

function ExcelUploadButton() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [previewData, setPreviewData] = useState<any[] | null>(null);
  const [open, setOpen] = useState(false);
  const [validationErrors, setValidationErrors] = useState<{ row: number; missing: string[] }[]>([]);
  const [validationOpen, setValidationOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const parseExcelDate = (value: any): string | null => {
    if (value == null || value === "") return null;
    // JS Date object (from cellDates: true)
    if (value instanceof Date && !isNaN(value.getTime())) {
      const y = value.getUTCFullYear();
      const m = String(value.getUTCMonth() + 1).padStart(2, "0");
      const d = String(value.getUTCDate()).padStart(2, "0");
      if (y > 1900 && y < 2100) return `${y}-${m}-${d}`;
    }
    // Excel serial number fallback
    if (typeof value === "number" && value > 0) {
      const ms = (value - 25569) * 86400 * 1000;
      const date = new Date(ms);
      const y = date.getUTCFullYear();
      const m = String(date.getUTCMonth() + 1).padStart(2, "0");
      const d = String(date.getUTCDate()).padStart(2, "0");
      if (y > 1900 && y < 2100) return `${y}-${m}-${d}`;
    }
    if (typeof value === "string" && value.trim()) {
      const s = value.trim();
      // ISO: 2026-04-17
      if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.substring(0, 10);
      // US: 4/17/2026 or 04/17/2026
      const us = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
      if (us) return `${us[3]}-${us[1].padStart(2, "0")}-${us[2].padStart(2, "0")}`;
    }
    return null;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const data = evt.target?.result;
      const wb = XLSX.read(data, { type: "array", cellDates: true });

      // Keywords that identify a data header row
      const isDataHeader = (cells: string[]) =>
        (cells.some((c) => c.includes("client name") || c.includes("client")) &&
          cells.some((c) => c.includes("policy"))) ||
        cells.some((c) => c.includes("assigned to")) ||
        cells.some((c) => c.includes("assigned by"));

      // Scan every sheet to find the one with data headers
      let chosenSheet = wb.SheetNames[0];
      let chosenHeaderRow = 0;
      let chosenRows: any[][] = [];

      for (const sName of wb.SheetNames) {
        const ws = wb.Sheets[sName];
        const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" }) as any[][];
        for (let i = 0; i < Math.min(rows.length, 10); i++) {
          const cells = rows[i].map((c: any) =>
            typeof c === "string" ? c.trim().toLowerCase() : ""
          );
          if (isDataHeader(cells)) {
            chosenSheet = sName;
            chosenHeaderRow = i;
            chosenRows = rows;
            break;
          }
        }
        if (chosenRows.length > 0) break;
      }

      // If no sheet matched, fall back to first sheet / first row and report all headers found
      if (chosenRows.length === 0) {
        const ws = wb.Sheets[wb.SheetNames[0]];
        chosenRows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" }) as any[][];
      }

      const rows = chosenRows;
      const headerRow = chosenHeaderRow;

      const headers = rows[headerRow].map((h: any) =>
        typeof h === "string" ? h.trim().toLowerCase() : ""
      );

      // Flexible column finder: returns index of first header matching any keyword
      const col = (keywords: string[]) =>
        headers.findIndex((h: string) => keywords.some((kw) => h.includes(kw)));

      // "Assigned To" → User
      const colUser      = col(["assigned to", "user"]);
      // "Current Date" → Checklist Date
      const colChecklist = col(["current date", "checklist date", "checklist", "date"]);
      const colClient    = col(["client name", "client"]);
      const colPolicy    = col(["policy number", "policy #", "policy num", "policy"]);
      const colLob       = col(["lob"]);
      const colTerm      = col(["term"]);
      // "Assigned By" → AM  (avoid substring "am" matching "client name")
      const colAm = (() => {
        const ab = headers.findIndex((h) => h.includes("assigned by"));
        if (ab !== -1) return ab;
        const acm = headers.findIndex((h) => h.includes("account manager") || h.includes("acct mgr"));
        if (acm !== -1) return acm;
        // Only exact "am" — never substring to avoid matching "client name"
        return headers.findIndex((h) => h === "am");
      })();
      const col1stSent   = col(["1st follow-up sent"]);
      const col1stDate   = col(["1st follow-up sent date"]);
      const col2ndSent   = col(["2nd follow-up sent"]);
      const col2ndDate   = col(["2nd follow-up sent date"]);
      const colPolSent   = col(["policy sent to client"]);
      const colPolDate   = col(["policy sent date"]);

      const str = (v: any) => (v != null && !(v instanceof Date) ? String(v).trim() : "");

      const records: any[] = [];
      const rowErrors: { row: number; missing: string[] }[] = [];
      let dataRowNum = 0;

      for (let i = headerRow + 1; i < rows.length; i++) {
        const row = rows[i];
        const clientName    = colClient    >= 0 ? str(row[colClient])    : "";
        const policyNumber  = colPolicy    >= 0 ? str(row[colPolicy])    : "";
        const userVal       = colUser      >= 0 ? str(row[colUser])      : "";
        const lobVal        = colLob       >= 0 ? str(row[colLob])       : "";
        const termVal       = colTerm      >= 0 ? str(row[colTerm])      : "";
        const amVal         = colAm        >= 0 ? str(row[colAm])        : "";
        const checklistDate = colChecklist >= 0 ? parseExcelDate(row[colChecklist]) : null;

        // Skip fully blank rows
        if (!clientName && !policyNumber && !userVal && !amVal) continue;
        dataRowNum++;

        // Validate required fields
        const missing: string[] = [];
        if (!userVal)        missing.push("Assigned To (User)");
        if (!checklistDate)  missing.push("Current Date (Checklist Date)");
        if (!clientName)     missing.push("Client Name");
        if (!policyNumber)   missing.push("Policy Number");
        if (!lobVal)         missing.push("LOB");
        if (!termVal)        missing.push("Term");
        if (!amVal)          missing.push("Assigned By (AM)");

        if (missing.length > 0) {
          rowErrors.push({ row: dataRowNum, missing });
          continue;
        }

        records.push({
          user: userVal,
          checklistDate: checklistDate!,
          clientName,
          policyNumber,
          lob:  lobVal,
          term: termVal,
          am:   amVal,
          firstFollowUpSent:      col1stSent >= 0 ? str(row[col1stSent])  || null : null,
          firstFollowUpSentDate:  col1stDate >= 0 ? parseExcelDate(row[col1stDate]) : null,
          secondFollowUpSent:     col2ndSent >= 0 ? str(row[col2ndSent]) || null : null,
          secondFollowUpSentDate: col2ndDate >= 0 ? parseExcelDate(row[col2ndDate]) : null,
          policySentToClient:     colPolSent >= 0 ? str(row[colPolSent]) || null : null,
          policySentDate:         colPolDate >= 0 ? parseExcelDate(row[colPolDate]) : null,
        });
      }

      if (rowErrors.length > 0) {
        setValidationErrors(rowErrors);
        setValidationOpen(true);
        e.target.value = "";
        return;
      }

      if (records.length === 0) {
        const foundHeaders = headers.filter(Boolean).join(", ") || "(none)";
        const allSheets = wb.SheetNames.join(", ");
        toast({
          title: "No records found",
          description: `Checked sheets: [${allSheets}]. Used sheet "${chosenSheet}" — headers found: ${foundHeaders}. Expected columns: "Client Name" and "Policy Number".`,
          variant: "destructive",
          duration: 10000,
        });
      }
      setPreviewData(records);
      setOpen(true);
    };
    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  const handleImport = async () => {
    if (!previewData || previewData.length === 0) return;
    setIsUploading(true);
    try {
      const base = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
      const res = await fetch(`${base}/api/follow-ups/bulk-import`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ records: previewData }),
      });
      const result = await res.json();
      if (res.ok) {
        queryClient.invalidateQueries({ queryKey: getListFollowUpsQueryKey() });
        toast({ title: "Import successful", description: `${result.imported} records imported.` });
        setOpen(false);
        setPreviewData(null);
      } else {
        toast({ title: "Import failed", description: result.error || "Unknown error", variant: "destructive" });
      }
    } catch {
      toast({ title: "Import failed", description: "Network error", variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <>
      <input
        ref={fileInputRef}
        type="file"
        accept=".xlsx,.xlsm,.xls"
        className="hidden"
        onChange={handleFileChange}
      />
      <Button className="gap-2" onClick={() => fileInputRef.current?.click()}>
        <Upload className="w-4 h-4" />
        Upload Excel
      </Button>

      {/* Validation error dialog */}
      <Dialog open={validationOpen} onOpenChange={setValidationOpen}>
        <DialogContent className="sm:max-w-[560px]">
          <DialogHeader>
            <DialogTitle className="text-destructive">Import Blocked — Missing Required Fields</DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <p className="text-sm text-muted-foreground mb-3">
              The following rows have missing required fields. Please fix them in your Excel file and try again. No data was imported.
            </p>
            <div className="max-h-[320px] overflow-auto rounded-md border border-destructive/20 bg-destructive/5">
              {validationErrors.map((e) => (
                <div key={e.row} className="px-4 py-2.5 border-b border-destructive/10 last:border-0">
                  <p className="text-sm font-medium text-foreground">Row {e.row}</p>
                  <p className="text-xs text-destructive mt-0.5">Missing: {e.missing.join(", ")}</p>
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setValidationOpen(false)}>OK, I'll fix the file</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setPreviewData(null); }}>
        <DialogContent className="sm:max-w-[620px]">
          <DialogHeader>
            <DialogTitle>Import Follow-Ups from Excel</DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <p className="text-sm text-muted-foreground mb-4">
              Found{" "}
              <span className="font-semibold text-foreground">{previewData?.length ?? 0}</span>{" "}
              valid records ready to import.
            </p>
            <div className="max-h-[300px] overflow-auto rounded-md border border-border/50">
              <Table>
                <TableHeader className="sticky top-0 bg-muted/80 z-10">
                  <TableRow className="text-xs">
                    <TableHead className="px-2 whitespace-nowrap">User</TableHead>
                    <TableHead className="px-2 whitespace-nowrap">Checklist Date</TableHead>
                    <TableHead className="px-2 whitespace-nowrap min-w-[140px]">Client Name</TableHead>
                    <TableHead className="px-2 whitespace-nowrap">Policy Number</TableHead>
                    <TableHead className="px-2 whitespace-nowrap">LOB</TableHead>
                    <TableHead className="px-2 whitespace-nowrap">Term</TableHead>
                    <TableHead className="px-2 whitespace-nowrap">AM</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {previewData?.slice(0, 25).map((r, i) => (
                    <TableRow key={i} className="text-xs">
                      <TableCell className="px-2 text-muted-foreground">{r.user}</TableCell>
                      <TableCell className="px-2 whitespace-nowrap">{r.checklistDate}</TableCell>
                      <TableCell className="px-2 font-medium whitespace-nowrap">{r.clientName}</TableCell>
                      <TableCell className="px-2 font-mono">{r.policyNumber}</TableCell>
                      <TableCell className="px-2">{r.lob}</TableCell>
                      <TableCell className="px-2">{r.term}</TableCell>
                      <TableCell className="px-2 whitespace-nowrap">{r.am}</TableCell>
                    </TableRow>
                  ))}
                  {(previewData?.length ?? 0) > 25 && (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-muted-foreground text-sm py-3">
                        +{previewData!.length - 25} more records not shown
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setOpen(false); setPreviewData(null); }}>
              Cancel
            </Button>
            <Button
              onClick={handleImport}
              disabled={isUploading || !previewData?.length}
              className="gap-2"
            >
              {isUploading ? "Importing..." : `Import ${previewData?.length ?? 0} Records`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function AddFollowUpDialog({ ams }: { ams: any[] }) {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({ clientName: "", policyNumber: "", lob: "", term: "", am: "", user: "current_user", checklistDate: format(new Date(), "yyyy-MM-dd") });
  const { mutate, isPending } = useCreateFollowUp();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate({ data: formData }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFollowUpsQueryKey() });
        setOpen(false);
        toast({ title: "Success", description: "Follow-up created successfully." });
        setFormData({ clientName: "", policyNumber: "", lob: "", term: "", am: "", user: "current_user", checklistDate: format(new Date(), "yyyy-MM-dd") });
      },
      onError: () => toast({ title: "Error", description: "Failed to create follow-up.", variant: "destructive" })
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          New Follow-Up
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>New Follow-Up Record</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Client Name</label>
              <Input required value={formData.clientName} onChange={e => setFormData(p => ({ ...p, clientName: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Policy Number</label>
              <Input required value={formData.policyNumber} onChange={e => setFormData(p => ({ ...p, policyNumber: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">LOB</label>
              <Input required value={formData.lob} onChange={e => setFormData(p => ({ ...p, lob: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Term</label>
              <Input required value={formData.term} onChange={e => setFormData(p => ({ ...p, term: e.target.value }))} />
            </div>
            <div className="space-y-2 col-span-2">
              <label className="text-sm font-medium">Account Manager</label>
              <Select value={formData.am} onValueChange={v => setFormData(p => ({ ...p, am: v }))} required>
                <SelectTrigger><SelectValue placeholder="Select AM" /></SelectTrigger>
                <SelectContent>
                  {ams.map(a => <SelectItem key={a.name} value={a.name}>{a.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Creating..." : "Create Record"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function EditFollowUpDialog({ followUp, ams }: { followUp: any, ams: any[] }) {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({ 
    clientName: followUp.clientName, 
    policyNumber: followUp.policyNumber, 
    lob: followUp.lob, 
    term: followUp.term, 
    am: followUp.am,
    firstFollowUpSent: followUp.firstFollowUpSent || "",
    secondFollowUpSent: followUp.secondFollowUpSent || "",
    policySentToClient: followUp.policySentToClient || "",
  });
  
  const { mutate, isPending } = useUpdateFollowUp();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate({ id: followUp.id, data: formData }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFollowUpsQueryKey() });
        setOpen(false);
        toast({ title: "Success", description: "Follow-up updated successfully." });
      },
      onError: () => toast({ title: "Error", description: "Failed to update follow-up.", variant: "destructive" })
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
          <Edit2 className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Update Record #{followUp.id}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">1st Follow-Up</label>
                <Select value={formData.firstFollowUpSent} onValueChange={v => setFormData(p => ({ ...p, firstFollowUpSent: v }))}>
                  <SelectTrigger><SelectValue placeholder="Pending" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Y">Sent (Y)</SelectItem>
                    <SelectItem value="N">Not Sent (N)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">2nd Follow-Up</label>
                <Select value={formData.secondFollowUpSent} onValueChange={v => setFormData(p => ({ ...p, secondFollowUpSent: v }))}>
                  <SelectTrigger><SelectValue placeholder="Pending" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Y">Sent (Y)</SelectItem>
                    <SelectItem value="N">Not Sent (N)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 col-span-2">
                <label className="text-sm font-medium">Policy Sent to Client</label>
                <Select value={formData.policySentToClient} onValueChange={v => setFormData(p => ({ ...p, policySentToClient: v }))}>
                  <SelectTrigger><SelectValue placeholder="Pending" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Y">Sent (Y)</SelectItem>
                    <SelectItem value="N">Not Sent (N)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="h-px bg-border my-2" />
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Client Name</label>
                <Input required value={formData.clientName} onChange={e => setFormData(p => ({ ...p, clientName: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Policy Number</label>
                <Input required value={formData.policyNumber} onChange={e => setFormData(p => ({ ...p, policyNumber: e.target.value }))} />
              </div>
              <div className="space-y-2 col-span-2">
                <label className="text-sm font-medium">Account Manager</label>
                <Select value={formData.am} onValueChange={v => setFormData(p => ({ ...p, am: v }))} required>
                  <SelectTrigger><SelectValue placeholder="Select AM" /></SelectTrigger>
                  <SelectContent>
                    {ams.map(a => <SelectItem key={a.name} value={a.name}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DeleteFollowUpButton({ id }: { id: number }) {
  const { mutate, isPending } = useDeleteFollowUp();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this record?")) {
      mutate({ id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListFollowUpsQueryKey() });
          toast({ title: "Deleted", description: "Record deleted." });
        },
        onError: () => toast({ title: "Error", description: "Failed to delete record.", variant: "destructive" })
      });
    }
  };

  return (
    <Button variant="ghost" size="icon" onClick={handleDelete} disabled={isPending} className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10">
      <Trash2 className="w-4 h-4" />
    </Button>
  );
}
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Activity } from "lucide-react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

type Tab = "signin" | "register" | "forgot";

export default function Login() {
  const { login } = useAuth();
  const [tab, setTab] = useState<Tab>("signin");

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [regDisplayName, setRegDisplayName] = useState("");
  const [regUsername, setRegUsername] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regConfirm, setRegConfirm] = useState("");
  const [regError, setRegError] = useState("");
  const [regSuccess, setRegSuccess] = useState("");

  const [fpUsername, setFpUsername] = useState("");
  const [fpCurrent, setFpCurrent] = useState("");
  const [fpNew, setFpNew] = useState("");
  const [fpConfirm, setFpConfirm] = useState("");
  const [fpError, setFpError] = useState("");
  const [fpSuccess, setFpSuccess] = useState("");

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(username, password);
    } catch (err: any) {
      setError(err.message || "Login failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError("");
    setRegSuccess("");
    if (regPassword !== regConfirm) {
      setRegError("Passwords do not match.");
      return;
    }
    if (regPassword.length < 4) {
      setRegError("Password must be at least 4 characters.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`${BASE}/api/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ displayName: regDisplayName, username: regUsername, password: regPassword }),
      });
      const data = await res.json();
      if (!res.ok) { setRegError(data.error || "Registration failed."); return; }
      setRegSuccess(`Account created! You can now sign in as "${regUsername}".`);
      setRegDisplayName(""); setRegUsername(""); setRegPassword(""); setRegConfirm("");
    } catch {
      setRegError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setFpError("");
    setFpSuccess("");
    if (fpNew !== fpConfirm) { setFpError("New passwords do not match."); return; }
    if (fpNew.length < 4) { setFpError("New password must be at least 4 characters."); return; }
    setLoading(true);
    try {
      const loginRes = await fetch(`${BASE}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ username: fpUsername, password: fpCurrent }),
      });
      if (!loginRes.ok) { setFpError("Username or current password is incorrect."); setLoading(false); return; }
      const changeRes = await fetch(`${BASE}/api/auth/change-password`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ currentPassword: fpCurrent, newPassword: fpNew }),
      });
      const changeData = await changeRes.json();
      if (!changeRes.ok) { setFpError(changeData.error || "Failed to change password."); return; }
      await fetch(`${BASE}/api/auth/logout`, { method: "POST", credentials: "include" });
      setFpSuccess("Password changed! Please sign in with your new password.");
      setFpUsername(""); setFpCurrent(""); setFpNew(""); setFpConfirm("");
    } catch {
      setFpError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const switchTab = (t: Tab) => {
    setTab(t);
    setError(""); setRegError(""); setRegSuccess(""); setFpError(""); setFpSuccess("");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8 gap-3">
          <div className="w-12 h-12 rounded-xl bg-sidebar-primary flex items-center justify-center text-white shadow-md">
            <Activity size={24} />
          </div>
          <div className="text-center">
            <h1 className="text-2xl font-bold tracking-tight text-foreground">PolicyTracker</h1>
            <p className="text-sm text-muted-foreground mt-1">
              {tab === "signin" && "Sign in to your account"}
              {tab === "register" && "Create a new account"}
              {tab === "forgot" && "Change your password"}
            </p>
          </div>
        </div>

        <div className="flex rounded-lg border border-border/50 bg-muted/40 p-1 mb-4 gap-1">
          {(["signin", "register", "forgot"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => switchTab(t)}
              className={`flex-1 text-xs font-medium py-1.5 px-2 rounded-md transition-colors ${
                tab === t
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t === "signin" && "Sign In"}
              {t === "register" && "New User"}
              {t === "forgot" && "Forgot Password"}
            </button>
          ))}
        </div>

        <div className="bg-background rounded-xl border border-border/50 shadow-sm p-6">
          {tab === "signin" && (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="username">Username</Label>
                <Input id="username" type="text" autoComplete="username" placeholder="Enter your username"
                  value={username} onChange={e => setUsername(e.target.value)} required disabled={loading} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">Password</Label>
                <Input id="password" type="password" autoComplete="current-password" placeholder="Enter your password"
                  value={password} onChange={e => setPassword(e.target.value)} required disabled={loading} />
              </div>
              {error && (
                <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">{error}</div>
              )}
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Signing in..." : "Sign In"}
              </Button>
              <p className="text-center text-xs text-muted-foreground pt-1">
                Forgot your password?{" "}
                <button type="button" onClick={() => switchTab("forgot")} className="text-primary underline underline-offset-2">Reset it here</button>
              </p>
            </form>
          )}

          {tab === "register" && (
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-1.5">
                <Label>Full Name</Label>
                <Input placeholder="Your display name" value={regDisplayName}
                  onChange={e => setRegDisplayName(e.target.value)} required disabled={loading} />
              </div>
              <div className="space-y-1.5">
                <Label>Username</Label>
                <Input placeholder="Choose a username" value={regUsername}
                  onChange={e => setRegUsername(e.target.value)} required disabled={loading} />
              </div>
              <div className="space-y-1.5">
                <Label>Password</Label>
                <Input type="password" placeholder="At least 4 characters" value={regPassword}
                  onChange={e => setRegPassword(e.target.value)} required disabled={loading} />
              </div>
              <div className="space-y-1.5">
                <Label>Confirm Password</Label>
                <Input type="password" placeholder="Repeat your password" value={regConfirm}
                  onChange={e => setRegConfirm(e.target.value)} required disabled={loading} />
              </div>
              {regError && (
                <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">{regError}</div>
              )}
              {regSuccess && (
                <div className="text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md px-3 py-2">{regSuccess}</div>
              )}
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Creating account..." : "Create Account"}
              </Button>
              {regSuccess && (
                <Button type="button" variant="outline" className="w-full" onClick={() => switchTab("signin")}>
                  Go to Sign In
                </Button>
              )}
            </form>
          )}

          {tab === "forgot" && (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div className="space-y-1.5">
                <Label>Username</Label>
                <Input placeholder="Your username" value={fpUsername}
                  onChange={e => setFpUsername(e.target.value)} required disabled={loading} />
              </div>
              <div className="space-y-1.5">
                <Label>Current Password</Label>
                <Input type="password" placeholder="Your current password" value={fpCurrent}
                  onChange={e => setFpCurrent(e.target.value)} required disabled={loading} />
              </div>
              <div className="space-y-1.5">
                <Label>New Password</Label>
                <Input type="password" placeholder="At least 4 characters" value={fpNew}
                  onChange={e => setFpNew(e.target.value)} required disabled={loading} />
              </div>
              <div className="space-y-1.5">
                <Label>Confirm New Password</Label>
                <Input type="password" placeholder="Repeat new password" value={fpConfirm}
                  onChange={e => setFpConfirm(e.target.value)} required disabled={loading} />
              </div>
              {fpError && (
                <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">{fpError}</div>
              )}
              {fpSuccess && (
                <div className="text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md px-3 py-2">{fpSuccess}</div>
              )}
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Updating..." : "Change Password"}
              </Button>
              {fpSuccess && (
                <Button type="button" variant="outline" className="w-full" onClick={() => switchTab("signin")}>
                  Go to Sign In
                </Button>
              )}
              <p className="text-center text-xs text-muted-foreground pt-1">
                Don't know your current password? Ask your admin to reset it.
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

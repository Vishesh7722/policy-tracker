import { useState } from "react";
import { 
  useListAccountManagers, 
  useCreateAccountManager, 
  useUpdateAccountManager, 
  useDeleteAccountManager,
  getListAccountManagersQueryKey 
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Edit2, Trash2, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

export default function AccountManagers() {
  const { data: ams, isLoading } = useListAccountManagers();

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-muted/30">
      <div className="p-6 border-b border-border/50 bg-background flex flex-col sm:flex-row sm:items-center justify-between gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Account Managers</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage team members and their assignments.</p>
        </div>
        <AddAmDialog />
      </div>

      <div className="flex-1 p-6 overflow-hidden">
        <div className="bg-background rounded-lg border border-border/50 shadow-sm max-w-4xl mx-auto">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="w-[100px] font-mono text-xs">ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-4 w-12" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-48" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : ams?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-12 text-muted-foreground">
                    No account managers found. Add one to get started.
                  </TableCell>
                </TableRow>
              ) : (
                ams?.map((am: any) => (
                  <TableRow key={am.id} className="group hover:bg-muted/30">
                    <TableCell className="font-mono text-xs text-muted-foreground">#{am.id}</TableCell>
                    <TableCell className="font-medium flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold">
                        {am.name.charAt(0)}
                      </div>
                      {am.name}
                    </TableCell>
                    <TableCell className="text-muted-foreground">{am.email}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <EditAmDialog am={am} />
                        <DeleteAmButton id={am.id} />
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

function AddAmDialog() {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({ name: "", email: "" });
  const { mutate, isPending } = useCreateAccountManager();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate({ data: formData }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAccountManagersQueryKey() });
        setOpen(false);
        toast({ title: "Success", description: "Account manager added." });
        setFormData({ name: "", email: "" });
      },
      onError: () => toast({ title: "Error", description: "Failed to add account manager.", variant: "destructive" })
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          Add Manager
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle>Add Account Manager</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Full Name</label>
            <Input required value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} placeholder="Jane Doe" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Email</label>
            <Input required type="email" value={formData.email} onChange={e => setFormData(p => ({ ...p, email: e.target.value }))} placeholder="jane@example.com" />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Adding..." : "Add Manager"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function EditAmDialog({ am }: { am: any }) {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({ name: am.name, email: am.email });
  const { mutate, isPending } = useUpdateAccountManager();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate({ id: am.id, data: formData }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAccountManagersQueryKey() });
        setOpen(false);
        toast({ title: "Success", description: "Account manager updated." });
      },
      onError: () => toast({ title: "Error", description: "Failed to update account manager.", variant: "destructive" })
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
          <Edit2 className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle>Edit Account Manager</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Full Name</label>
            <Input required value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Email</label>
            <Input required type="email" value={formData.email} onChange={e => setFormData(p => ({ ...p, email: e.target.value }))} />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DeleteAmButton({ id }: { id: number }) {
  const { mutate, isPending } = useDeleteAccountManager();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this account manager?")) {
      mutate({ id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListAccountManagersQueryKey() });
          toast({ title: "Deleted", description: "Account manager deleted." });
        },
        onError: () => toast({ title: "Error", description: "Failed to delete account manager.", variant: "destructive" })
      });
    }
  };

  return (
    <Button variant="ghost" size="icon" onClick={handleDelete} disabled={isPending} className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10">
      <Trash2 className="w-4 h-4" />
    </Button>
  );
}

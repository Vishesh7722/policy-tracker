import { useState } from "react";
import { useGetDashboard, useGetStatusBreakdown, useGetAmWorkload, useGetRecentActivity } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, CheckCircle2, Clock, Inbox, TrendingUp, Users } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function Dashboard() {
  const { data: stats, isLoading: isStatsLoading } = useGetDashboard();
  const { data: statusBreakdown, isLoading: isStatusLoading } = useGetStatusBreakdown();
  const { data: amWorkload, isLoading: isWorkloadLoading } = useGetAmWorkload();
  const { data: recentActivity, isLoading: isActivityLoading } = useGetRecentActivity();

  return (
    <div className="flex-1 overflow-y-auto p-8 bg-muted/30">
      <div className="max-w-7xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Command Center</h1>
          <p className="text-muted-foreground mt-2">Overview of today's critical items and team performance.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Due Today"
            value={stats?.dueTodayCount}
            icon={<Clock className="w-4 h-4 text-orange-500" />}
            isLoading={isStatsLoading}
            description="Follow-ups requiring action today"
          />
          <StatCard
            title="Escalations"
            value={stats?.escalations}
            icon={<AlertCircle className="w-4 h-4 text-destructive" />}
            isLoading={isStatsLoading}
            description="2nd follow-up escalations"
          />
          <StatCard
            title="Total Active"
            value={stats?.totalActive}
            icon={<Inbox className="w-4 h-4 text-primary" />}
            isLoading={isStatsLoading}
            description="Policies actively being tracked"
          />
          <StatCard
            title="Closed This Week"
            value={stats?.closedThisWeek}
            icon={<CheckCircle2 className="w-4 h-4 text-green-500" />}
            isLoading={isStatsLoading}
            description="Successfully completed"
          />
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
          <Card className="col-span-4 border-border/50 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                Team Workload
              </CardTitle>
              <CardDescription>Active tracking distribution by Account Manager</CardDescription>
            </CardHeader>
            <CardContent>
              {isWorkloadLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-12 w-full" />)}
                </div>
              ) : (
                <div className="space-y-4">
                  {amWorkload?.map((workload: any) => (
                    <div key={workload.am} className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-card hover:bg-muted/50 transition-colors">
                      <div className="font-medium">{workload.am}</div>
                      <div className="flex items-center gap-4 text-sm">
                        <div className="flex flex-col items-center">
                          <span className="text-muted-foreground text-xs">Total</span>
                          <span className="font-semibold">{workload.total}</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <span className="text-muted-foreground text-xs">Pending</span>
                          <span className="font-semibold text-orange-500">{workload.pending}</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <span className="text-muted-foreground text-xs">Escalated</span>
                          <span className="font-semibold text-destructive">{workload.escalations}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                  {(!amWorkload || amWorkload.length === 0) && (
                    <div className="text-center py-8 text-muted-foreground">No workload data available.</div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="col-span-3 border-border/50 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Status Breakdown
              </CardTitle>
              <CardDescription>Current state of all active items</CardDescription>
            </CardHeader>
            <CardContent>
              {isStatusLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-10 w-full" />)}
                </div>
              ) : (
                <div className="space-y-3">
                  {statusBreakdown?.map((status: any) => (
                    <div key={status.status} className="flex items-center justify-between p-2.5 rounded border border-border/50">
                      <div className="flex items-center gap-2">
                        <StatusIndicator status={status.status} />
                        <span className="text-sm font-medium">{status.status}</span>
                      </div>
                      <span className="font-semibold">{status.count}</span>
                    </div>
                  ))}
                  {(!statusBreakdown || statusBreakdown.length === 0) && (
                    <div className="text-center py-8 text-muted-foreground">No status data available.</div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, isLoading, description }: any) {
  return (
    <Card className="border-border/50 shadow-sm overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-8 w-16" />
        ) : (
          <>
            <div className="text-3xl font-bold tracking-tight">{value ?? 0}</div>
            {description && <p className="text-xs text-muted-foreground mt-1">{description}</p>}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function StatusIndicator({ status }: { status: string }) {
  const colors: Record<string, string> = {
    "Waiting": "bg-slate-400",
    "1st Follow-Up Pending": "bg-amber-400",
    "2nd Follow-Up Pending": "bg-orange-500",
    "2nd Follow-Up Escalation": "bg-red-500",
    "Closed": "bg-emerald-500"
  };
  
  return (
    <div className={`w-3 h-3 rounded-full ${colors[status] || "bg-slate-400"}`} />
  );
}

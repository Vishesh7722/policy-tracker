import { useState } from "react";
import { Link, useLocation } from "wouter";
import { LayoutDashboard, FileText, ClipboardList, Users, Download, Activity, LogOut, ShieldCheck, KeyRound } from "lucide-react";
import { cn } from "@/lib/utils";
import { useHealthCheck } from "@workspace/api-client-react";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

function ChangePasswordDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { toast } = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const reset = () => { setCurrent(""); setNext(""); setConfirm(""); setError(""); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (next !== confirm) { setError("New passwords do not match."); return; }
    if (next.length < 4) { setError("New password must be at least 4 characters."); return; }
    setSaving(true);
    try {
      const res = await fetch(`${BASE}/api/auth/change-password`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ currentPassword: current, newPassword: next }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || "Failed to change password."); return; }
      toast({ title: "Password changed", description: "Your password has been updated." });
      onOpenChange(false);
      reset();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) reset(); }}>
      <DialogContent className="sm:max-w-[380px]">
        <DialogHeader>
          <DialogTitle>Change Password</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>Current Password</Label>
            <Input type="password" placeholder="Your current password" value={current}
              onChange={e => setCurrent(e.target.value)} required disabled={saving} />
          </div>
          <div className="space-y-1.5">
            <Label>New Password</Label>
            <Input type="password" placeholder="At least 4 characters" value={next}
              onChange={e => setNext(e.target.value)} required disabled={saving} />
          </div>
          <div className="space-y-1.5">
            <Label>Confirm New Password</Label>
            <Input type="password" placeholder="Repeat new password" value={confirm}
              onChange={e => setConfirm(e.target.value)} required disabled={saving} />
          </div>
          {error && (
            <p className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">{error}</p>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={saving}>{saving ? "Saving..." : "Update Password"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { data: health } = useHealthCheck();
  const { user, logout } = useAuth();
  const [changePwOpen, setChangePwOpen] = useState(false);

  const NAV_ITEMS = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/follow-ups", label: "Follow-Ups", icon: ClipboardList },
    { href: "/policy-log", label: "Policy Sent Log", icon: FileText },
    { href: "/account-managers", label: "Account Managers", icon: Users },
    { href: "/export", label: "Export", icon: Download },
    ...(user?.role === "admin" ? [{ href: "/users", label: "Users", icon: ShieldCheck }] : []),
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row bg-background">
      <aside className="w-full md:w-64 bg-sidebar border-r border-sidebar-border flex flex-col flex-shrink-0 z-20">
        <div className="p-6 pb-2 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-md bg-sidebar-primary flex items-center justify-center text-sidebar-primary-foreground">
              <Activity size={18} />
            </div>
            <div>
              <h1 className="font-semibold text-sidebar-foreground leading-tight tracking-tight">PolicyTracker</h1>
              <p className="text-xs text-sidebar-accent-foreground opacity-70">Brokerage Command Center</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const isActive = location === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )}
              >
                <item.icon size={16} className={isActive ? "text-sidebar-primary" : "text-sidebar-foreground/60"} />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-sidebar-border mt-auto space-y-3">
          {user && (
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="text-xs font-medium text-sidebar-foreground truncate">{user.displayName}</p>
                <p className="text-xs text-sidebar-accent-foreground/60 truncate">{user.username}</p>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-sidebar-accent-foreground/60 hover:text-sidebar-foreground"
                  title="Change password"
                  onClick={() => setChangePwOpen(true)}
                >
                  <KeyRound size={14} />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-sidebar-accent-foreground/60 hover:text-sidebar-foreground"
                  title="Sign out"
                  onClick={logout}
                >
                  <LogOut size={14} />
                </Button>
              </div>
            </div>
          )}
          <div className="flex items-center justify-between text-xs text-sidebar-accent-foreground/60">
            <span>System Status</span>
            <div className="flex items-center gap-1.5">
              <div className={cn("w-2 h-2 rounded-full", health?.status === "ok" ? "bg-green-500" : "bg-red-500")} />
              {health?.status === "ok" ? "Online" : "Offline"}
            </div>
          </div>
        </div>
      </aside>
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden bg-background">
        {children}
      </main>

      <ChangePasswordDialog open={changePwOpen} onOpenChange={setChangePwOpen} />
    </div>
  );
}

import { pgTable, serial, text, date, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const followUpsTable = pgTable("follow_ups", {
  id: serial("id").primaryKey(),
  user: text("user").notNull(),
  checklistDate: date("checklist_date").notNull(),
  clientName: text("client_name").notNull(),
  policyNumber: text("policy_number").notNull(),
  lob: text("lob").notNull(),
  term: text("term").notNull().default(""),
  am: text("am").notNull(),
  firstFollowUpSent: text("first_follow_up_sent"),
  firstFollowUpSentDate: date("first_follow_up_sent_date"),
  secondFollowUpSent: text("second_follow_up_sent"),
  secondFollowUpSentDate: date("second_follow_up_sent_date"),
  policySentToClient: text("policy_sent_to_client"),
  policySentDate: date("policy_sent_date"),
  policySentByUser: text("policy_sent_by_user"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertFollowUpSchema = createInsertSchema(followUpsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertFollowUp = z.infer<typeof insertFollowUpSchema>;
export type FollowUp = typeof followUpsTable.$inferSelect;

import { pgTable, serial, text } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const accountManagersTable = pgTable("account_managers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
});

export const insertAccountManagerSchema = createInsertSchema(accountManagersTable).omit({ id: true });

export type InsertAccountManager = z.infer<typeof insertAccountManagerSchema>;
export type AccountManager = typeof accountManagersTable.$inferSelect;

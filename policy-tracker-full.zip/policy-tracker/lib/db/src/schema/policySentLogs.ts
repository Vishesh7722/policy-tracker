import { pgTable, serial, text, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const policySentLogsTable = pgTable("policy_sent_logs", {
  id: serial("id").primaryKey(),
  clientName: text("client_name").notNull(),
  policyNumber: text("policy_number").notNull(),
  lob: text("lob").notNull(),
  term: text("term").notNull().default(""),
  am: text("am").notNull(),
  sentDate: date("sent_date").notNull(),
  sentBy: text("sent_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPolicySentLogSchema = createInsertSchema(policySentLogsTable).omit({
  id: true,
  createdAt: true,
});

export type InsertPolicySentLog = z.infer<typeof insertPolicySentLogSchema>;
export type PolicySentLog = typeof policySentLogsTable.$inferSelect;

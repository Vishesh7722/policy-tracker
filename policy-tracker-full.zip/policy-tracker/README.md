# PolicyTracker

A full-stack insurance policy follow-up tracker — converted from an Excel workbook.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19 + Vite + TypeScript |
| Backend | Node.js + Express + TypeScript |
| Database | PostgreSQL + Drizzle ORM |
| Styling | Tailwind CSS v4 + shadcn/ui |
| Auth | express-session + bcryptjs |
| Package manager | pnpm (workspaces monorepo) |

---

## Prerequisites

- **Node.js** v20 or later — https://nodejs.org
- **pnpm** v9 or later — `npm install -g pnpm`
- **PostgreSQL** 15+ running locally or a hosted connection string

---

## 1 — Clone & install

```bash
git clone <your-repo-url>
cd policy-tracker
pnpm install
```

---

## 2 — Set up environment variables

```bash
cp artifacts/api-server/.env.example artifacts/api-server/.env
```

Open `artifacts/api-server/.env` and fill in your values:

```env
DATABASE_URL=postgresql://postgres:password@localhost:5432/policy_tracker
SESSION_SECRET=replace-with-a-long-random-string
PORT=8080
NODE_ENV=development
```

> **Tip:** Generate a strong SESSION_SECRET with:
> ```bash
> node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
> ```

---

## 3 — Create the database & push schema

Create the database in PostgreSQL first:

```sql
CREATE DATABASE policy_tracker;
```

Then push the Drizzle schema:

```bash
pnpm --filter @workspace/db run push
```

---

## 4 — Run the app (two terminals)

**Terminal 1 — API server:**
```bash
pnpm --filter @workspace/api-server run dev
# Starts on http://localhost:8080
```

**Terminal 2 — Frontend:**
```bash
pnpm --filter @workspace/policy-tracker run dev
# Opens on http://localhost:5173
```

Then open **http://localhost:5173** in your browser.

---

## 5 — Default admin login

| Field | Value |
|---|---|
| Username | `admin` |
| Password | `admin123` |

**Change this immediately** after first login via the sidebar key icon (🔑).

---

## Project Structure

```
policy-tracker/
├── artifacts/
│   ├── api-server/          ← Express REST API
│   │   ├── src/
│   │   │   ├── app.ts       ← Express app + middleware
│   │   │   ├── index.ts     ← server entry point
│   │   │   ├── lib/
│   │   │   │   ├── logger.ts
│   │   │   │   └── businessDays.ts   ← WORKDAY() logic
│   │   │   └── routes/
│   │   │       ├── auth.ts           ← login/logout/register/password
│   │   │       ├── followUps.ts      ← main CRUD + Excel export
│   │   │       ├── bulkImport.ts     ← Excel upload endpoint
│   │   │       ├── accountManagers.ts
│   │   │       ├── policySentLogs.ts
│   │   │       └── dashboard.ts      ← KPI data
│   │   ├── .env.example
│   │   └── package.json
│   │
│   └── policy-tracker/      ← React + Vite frontend
│       ├── src/
│       │   ├── App.tsx               ← routes + auth guard
│       │   ├── context/AuthContext.tsx
│       │   ├── components/layout.tsx ← sidebar
│       │   └── pages/
│       │       ├── login.tsx         ← sign in / register / forgot password
│       │       ├── dashboard.tsx
│       │       ├── follow-ups.tsx    ← main table + Excel import
│       │       ├── policy-log.tsx    ← closed records
│       │       ├── account-managers.tsx
│       │       ├── users.tsx         ← admin user management
│       │       └── export.tsx
│       └── package.json
│
└── lib/
    ├── db/                  ← Drizzle schema + migrations
    │   └── src/
    │       ├── schema.ts    ← all table definitions
    │       └── index.ts
    ├── api-spec/            ← OpenAPI spec (orval codegen)
    ├── api-client-react/    ← generated React Query hooks
    └── api-zod/             ← generated Zod schemas
```

---

## API Endpoints

### Auth
| Method | Path | Description |
|---|---|---|
| POST | `/api/auth/login` | Sign in |
| POST | `/api/auth/logout` | Sign out |
| GET | `/api/auth/me` | Current session |
| POST | `/api/auth/register` | Self-register (user role) |
| PUT | `/api/auth/change-password` | Change own password |

### Users (admin only)
| Method | Path | Description |
|---|---|---|
| GET | `/api/users` | List all users |
| POST | `/api/users` | Create user |
| PUT | `/api/users/:id/reset-password` | Reset any user's password |
| DELETE | `/api/users/:id` | Delete user |

### Follow-Ups
| Method | Path | Description |
|---|---|---|
| GET | `/api/follow-ups` | List (search, filter, sort, paginate) |
| POST | `/api/follow-ups` | Create |
| GET | `/api/follow-ups/:id` | Get one |
| PUT | `/api/follow-ups/:id` | Update |
| DELETE | `/api/follow-ups/:id` | Delete |
| GET | `/api/follow-ups/export` | Download Excel file |
| POST | `/api/follow-ups/bulk-import` | Import from Excel |

### Dashboard
| Method | Path | Description |
|---|---|---|
| GET | `/api/dashboard` | KPI summary |
| GET | `/api/dashboard/status-breakdown` | Counts per status |
| GET | `/api/dashboard/am-workload` | Per-AM workload |
| GET | `/api/dashboard/recent-activity` | Last 10 updated records |

### Other
| Method | Path | Description |
|---|---|---|
| GET/POST | `/api/account-managers` | List + create |
| PUT/DELETE | `/api/account-managers/:id` | Update/delete |
| GET/POST | `/api/policy-sent-logs` | List + create |
| DELETE | `/api/policy-sent-logs/:id` | Delete |

---

## Business Logic (replicated from Excel)

- **1st Follow-Up Due** = WORKDAY(Checklist Date, 5)
- **2nd Follow-Up Due** = WORKDAY(1st Sent Date, 5)
- **Status** (priority order):
  1. `Closed` — if Policy Sent to Client = Y
  2. `2nd Follow-Up Escalation` — if 2nd sent and today > WORKDAY(2nd sent date, 2)
  3. `2nd Follow-Up Pending` — if 1st sent, 2nd not sent, today > 2nd due date
  4. `1st Follow-Up Pending` — if 1st not sent and today > 1st due date
  5. `Waiting` — otherwise

---

## Database Tables

| Table | Purpose |
|---|---|
| `app_users` | Login accounts (username, bcrypt hash, display name, role) |
| `session` | Express session store (auto-created) |
| `follow_ups` | Main tracking records |
| `account_managers` | AM name + email |
| `policy_sent_logs` | Audit log of sent policies |

---

## VS Code Tips

Install these extensions for the best experience:
- **ESLint** — `dbaeumer.vscode-eslint`
- **Prettier** — `esbenp.prettier-vscode`
- **Tailwind CSS IntelliSense** — `bradlc.vscode-tailwindcss`
- **Drizzle ORM** — `drizzle-team.drizzle-vscode`

---

## Deployment (production)

1. Build the frontend: `pnpm --filter @workspace/policy-tracker run build`
2. Build the API: `pnpm --filter @workspace/api-server run build`
3. Serve the frontend `dist/` folder from your web server (nginx, etc.)
4. Run the API with: `node artifacts/api-server/dist/index.mjs`
5. Set `NODE_ENV=production` and a strong `SESSION_SECRET` in your environment
